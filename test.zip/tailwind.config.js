module.exports = {
  content: ['./src/**/*.{js,jsx,vue}'],
  theme: {
    extend: {},
  },
  plugins: [],
}
